package userPackage;

import java.awt.Color;
import java.awt.Component;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import javax.imageio.ImageIO;
import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JList;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.JTextField;

import resource.FontPersonalizado;


public class PrivadoModal extends JDialog{

	/**
	 * 
	 */
	public String response;
	private static final long serialVersionUID = 1L;
	public JList listaNombres;
	public String nombreElejido;
	public JTextField salaACrear;
	static final int WIDTH = 920;
	static final int HEIGHT = 640;


	public  PrivadoModal(AppChat parent , boolean modal , String string){
	super(parent , modal);
	setUndecorated(true);
	pack();
	

	
	setLayout(null);
	setSize(WIDTH , HEIGHT);
	setLocationRelativeTo(parent);
 	setTitle("Salas Disponibles");
	
 	
 	Panel panel = new Panel();
 	System.out.println(string);
 	panel.setLayout(null);
 	panel.setSize(WIDTH , HEIGHT);
 	getContentPane().add(panel);


 	
 	List<String> salas = new ArrayList();
 	
 	

 	String nombresSalas[] = string.split(":");
 	listaNombres = new JList( nombresSalas );
 	listaNombres.setBackground(Color.BLACK);
 	listaNombres.setForeground(Color.WHITE);
 	listaNombres.setFont(new Font("OCR A", Font.BOLD, 16));
 	listaNombres.setBounds(20, 20, 180, 50);
 
 	JScrollPane paneScroll = new JScrollPane(listaNombres);
	paneScroll.setBounds(50, 90, 550, 250);
	panel.add(paneScroll);
	
	this.salaACrear = new JTextField();
	salaACrear.setBounds(50, 410, 550, 30);
	salaACrear.setBackground(Color.BLACK);
	salaACrear.setForeground(Color.WHITE);
	salaACrear.setFont(new Font("OCR A", Font.BOLD, 16));
	panel.add(salaACrear);
	
 	JButton botonSend = new JButton("Enviar");
 	botonSend.setBounds(780, 550 , 100, 40);
 	JButton botonCreate = new JButton("Cancelar");
 	botonCreate.setBounds(40, 550, 100, 40);
 	botonCreate.addActionListener(new ActionListener() {
		@Override
		public void actionPerformed(ActionEvent e) {
			if ( salaACrear.getText().isEmpty())
				nombreElejido = "";
				setVisible(false);
		}
	});
 	
 	botonSend.addActionListener(new ActionListener() {
		@Override
		public void actionPerformed(ActionEvent e) {
			
			if (listaNombres.getSelectedValue() == null )
				JOptionPane.showMessageDialog(null, "Ingrese nombre de usuario");
			else {
				String salas = listaNombres.getSelectedValue().toString();
				nombreElejido =  salas + "@" + parent.getUserName() + "@ " + "Mensaje Privado de " + parent.getUserName() + " a " + salas  + " " + parent.obtenerFecha() +  " : "+salaACrear.getText()+ "\n";
				System.out.println(nombreElejido);
				setVisible(false);
			}
		}
	});
 	panel.add(botonSend);
 	panel.add(botonCreate);


 	panel.repaint();
 	
 	setVisible(true);
	}
	

	
	private class Panel extends JPanel{

		private BufferedImage backgroundChat;


		/**
		 * 
		 */
		public Panel() {
			try {
				backgroundChat = ImageIO.read(new File("Resources/back_chat.jpg"));
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		private static final long serialVersionUID = 1L;

		
		@Override
		public void paintComponent(Graphics g) {
			// TODO Auto-generated method stub
			super.paintComponent(g);
			
			Graphics2D g2 = (Graphics2D) g;
			g2.drawImage(backgroundChat, 0, 0, UserProfileModal.WIDTH, UserProfileModal.HEIGHT +1, null);
			FontPersonalizado.dibujarTexto(g2, "Elija Usuario", 30 , 45, 32,32, 25);
			FontPersonalizado.dibujarTexto(g2, "Mensaje Privado", 30 , 370, 32,32, 25);
			g2.setColor(Color.BLACK);

		}
		
		@Override
		public Dimension getPreferredSize() {
			// TODO Auto-generated method stub
			return new Dimension(PrivadoModal.WIDTH , PrivadoModal.HEIGHT);
		}
	}



	public String obtenerNombre() {
		// TODO Auto-generated method stub
		return null;
	}



	public void mostrarSalas() {
		
	}
	
}
