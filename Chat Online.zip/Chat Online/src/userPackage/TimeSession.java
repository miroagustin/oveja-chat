package userPackage;

import java.awt.event.ActionEvent;
import java.time.LocalDateTime;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.Timer;

public class TimeSession implements Runnable{
	private int segundos;
	private LocalDateTime fechaInicio;
	private UserUI interfaz;
	
	
	
	public TimeSession(LocalDateTime fechaInicio,UserUI interfaz) {
		this.fechaInicio = fechaInicio;
		this.interfaz = interfaz;
		this.segundos = 57;
		
		interfaz.segundos = 57;
		
		Timer timer = new Timer(1000, new ActionListener(){
            @Override
            public void actionPerformed(ActionEvent e) {
            	if (interfaz.segundos< 59)
            	interfaz.segundos++;
            	else {
            		interfaz.minutos++; 
            		if (interfaz.minutos > 59) {
            			interfaz.minutos = 0;
            			interfaz.hora++;
            		}
            		interfaz.segundos = 0;
            	}
            	
                interfaz.repaint();
            }
        });
		timer.start();
	}
	public int getSegundos() {
		return segundos;
	}
	public void setSegundos(int segundos) {
		this.segundos = segundos;
	}
	public LocalDateTime getFechaInicio() {
		return fechaInicio;
	}
	public void setFechaInicio(LocalDateTime fechaInicio) {
		this.fechaInicio = fechaInicio;
	}
	public UserUI getInterfaz() {
		return interfaz;
	}
	public void setInterfaz(UserUI interfaz) {
		this.interfaz = interfaz;
	}
	@Override
	public void run() {
		Boolean canShow = true;
		while(canShow) {
			
		}
		
	}
	
	

}
