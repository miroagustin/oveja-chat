package server;

import java.io.ObjectOutputStream;
import java.time.LocalDateTime;

public class ClientService {
	private String nombre;
	private ObjectOutputStream salida;
	private LocalDateTime fechaInicio;
	
	public ClientService(String nombre, ObjectOutputStream salida,LocalDateTime fechaInicio) {
		
		this.fechaInicio = fechaInicio;
		this.nombre = nombre;
		this.salida = salida;
		
	}

	public String getNombre() {
		return nombre;
	}

	public void setNombre(String nombre) {
		this.nombre = nombre;
	}

	public ObjectOutputStream getSalida() {
		return salida;
	}

	public void setSalida(ObjectOutputStream salida) {
		this.salida = salida;
	}

	public LocalDateTime getFechaInicio() {
		return fechaInicio;
	}

	public void setFechaInicio(LocalDateTime fechaInicio) {
		this.fechaInicio = fechaInicio;
	}

}
