package resource;

import java.awt.Graphics2D;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import java.util.ArrayList;

import javax.imageio.ImageIO;

public class FontPersonalizado {
	public static ArrayList<BufferedImage> font = new ArrayList<>();
	
	static public  void iniciar() {
	font = new ArrayList<BufferedImage>();
		try {
			for (int i = 0; i < 99; i++) {
				font.add(ImageIO.read(new File( "font/" + (i+1) + ".png")));
			}
		} catch (IOException e) {
			e.printStackTrace();
		}
		
	}
	
	static public void dibujarTexto(Graphics2D g, String string, int x, int y , int ancho , int alto , int cant_espacio) {
		String espacio = " ";
		for (int i = 0; i < string.length(); i++) {
			g.drawImage(FontPersonalizado.font.get(Math.max(string.codePointAt(i) - espacio.codePointAt(0), 0)), x + cant_espacio * i, y,ancho,alto , null);
		}

	}
	
}
