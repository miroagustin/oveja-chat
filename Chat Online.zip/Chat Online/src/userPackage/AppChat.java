package userPackage;

import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.Socket;
import java.time.LocalDateTime;

import javax.imageio.ImageIO;
import javax.swing.JFrame;

import resource.FontPersonalizado;
import server.Action;
import server.ClientService;
import server.PaqueteMensaje;

public class AppChat extends JFrame implements Runnable {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	//Resources
	
	public  BufferedImage backgroundChat;
	private Socket socket;
	private ObjectOutputStream flujoSalida;
	private ObjectInputStream flujoEntrada;
	private UserProfileModal userInfo;
	private String salaActual;
	public LocalDateTime fechaInicio;
	public int segundos;
	private TimeSession session;
	
	public UserUI getInterfaz() {
		return interfaz;
	}

	public void setInterfaz(UserUI interfaz) {
		this.interfaz = interfaz;
	}

	public String getUserName() {
		return userName;
	}

	public String getSalaActual() {
		return salaActual;
	}

	public void setSalaActual(String salaActual) {
		this.salaActual = salaActual;
	}

	public void setUserName(String userName) {
		this.userName = userName;
	}

	private UserUI interfaz;
	private String userName;
	
	public static void main(String[] args) {
		
		AppChat app = new AppChat();
		
		app.iniciarInterfaz();
	}

	private void iniciarInterfaz() {
		
		// Iniciar Imagenes
		try {
			backgroundChat = ImageIO.read(new File("Resources/back_chat.jpg"));
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		FontPersonalizado.iniciar(); 
		interfaz = new UserUI(this);
		add(interfaz);
		pack();
		setLayout(null);
		setDefaultCloseOperation(EXIT_ON_CLOSE);
		setLocationRelativeTo(null);
		setResizable(false);
		setVisible(true);
		setFocusable(true);
		setTitle("Chat Online");
		requestFocusInWindow();
		repaint();
		userInfo = new UserProfileModal(this, true, "Ingrese info");
		userName = userInfo.response;
		repaint();
		
		interfaz.repaint();
		System.out.println(userName);
		
		conectar("localhost",10578);
		System.out.println("Te conectaste al servidor");
		
		new Thread(this).start();
	}

	public Socket getSocket() {
		return socket;
	}

	public void setSocket(Socket socket) {
		this.socket = socket;
	}

	public ObjectOutputStream getFlujoSalida() {
		return flujoSalida;
	}

	public void setFlujoSalida(ObjectOutputStream flujoSalida) {
		this.flujoSalida = flujoSalida;
	}

	public ObjectInputStream getFlujoEntrada() {
		return flujoEntrada;
	}

	public void setFlujoEntrada(ObjectInputStream flujoEntrada) {
		this.flujoEntrada = flujoEntrada;
	}

	private void conectar(String ip ,int port ) {
		// TODO Auto-generated method stub
		try {
			socket = new Socket(ip,port);
			setFlujoSalida(new ObjectOutputStream (socket.getOutputStream()));
			setFlujoEntrada(new ObjectInputStream(socket.getInputStream()));
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			
			
		}
	}
	public void desconectar() {
		try {
			flujoEntrada.close();
			socket.close();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	public void enviarMensaje(String text , Action accion) {
		try {
			flujoSalida.writeObject( new PaqueteMensaje(text , accion));
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	public String obtenerFecha() {
		return  LocalDateTime.now().getDayOfMonth() + "/" + LocalDateTime.now().getMonthValue() + "/" +LocalDateTime.now().getYear() + " " +  LocalDateTime.now().getHour() + ":" + LocalDateTime.now().getMinute() + ":" + LocalDateTime.now().getSecond();
	}
	@Override
	public void run() {
		PaqueteMensaje paquete;
		boolean canRecibe = true;
		
		try {
			flujoSalida.writeObject( new PaqueteMensaje(this.userName , Action.RECIBIRNOMBRE));
			paquete = (PaqueteMensaje) flujoEntrada.readObject();
			interfaz.agregarListaConectados();
			SalasModal modalSalas	 = new SalasModal(this, true, paquete.text);
			modalSalas.mostrarSalas();
			salaActual = modalSalas.salaElejida;
			flujoSalida.writeObject( new PaqueteMensaje(salaActual , Action.ELEJIRSALA));
			//fechaInicio =  LocalDateTime.now();
			session = new TimeSession(LocalDateTime.now(), this.interfaz);
			interfaz.repaint();
			
		} catch (IOException | ClassNotFoundException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		
		
		while (canRecibe) {
			
			try {
				paquete = (PaqueteMensaje) flujoEntrada.readObject();
				

				switch (paquete.accion) {
				case MENSAJECHAT:
					this.interfaz.recibirChat(paquete.text);
					break;
				case ELEJIRSALA:
					
					break;
				case ENVIARTEXTO:
					this.interfaz.recibirChat(paquete.text);
					
					break;
				case OBTENERUSUARIOS:
					interfaz.actualizarUsuarios(paquete.text);
					System.out.println(paquete.text);
					break;
				default:
					this.interfaz.recibirChat(paquete.text);
					break;
				}
				
			} catch (IOException  | ClassNotFoundException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
				canRecibe = false;
			}
			
		}
		
	}

}
