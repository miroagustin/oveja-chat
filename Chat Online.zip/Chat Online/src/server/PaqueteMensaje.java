package server;

import java.io.Serializable;

public class PaqueteMensaje implements Serializable{
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	public String text;
	public Action accion;
	
	public PaqueteMensaje(String text,Action accion) {
		this.text = text;
		this.accion = accion;
	}

}
