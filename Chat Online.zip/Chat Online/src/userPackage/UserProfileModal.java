package userPackage;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;

import javax.imageio.ImageIO;
import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextArea;
import javax.swing.JTextField;



public class UserProfileModal extends JDialog{

	/**
	 * 
	 */
	public String response;
	private JTextField areaNombre;
	private static final long serialVersionUID = 1L;
	public BufferedImage background;
	static final int WIDTH = 920;
	static final int HEIGHT = 640;
	

	public  UserProfileModal(JFrame parent , boolean modal , String string){
	super(parent , modal);
	setUndecorated(true);
	pack();
	
	try {
		background = ImageIO.read(new File("Resources/login.jpg"));
	} catch (IOException e1) {
		// TODO Auto-generated catch block
		e1.printStackTrace();
	}
//	Dimension pantalla = java.awt.Toolkit.getDefaultToolkit().getScreenSize();
	
	//Dimension ventana = getSize();
	
	setLayout(null);
	setSize(WIDTH , HEIGHT);
	setLocationRelativeTo(parent);
 	setTitle("Ingrese nombre de usuario");
	
 	
 	Panel panel = new Panel();
 	
 	panel.setLayout(null);
 	panel.setSize(WIDTH , HEIGHT);
 	getContentPane().add(panel);
 	JLabel text = new JLabel("Usuario");
 	text.setLocation(10,58);
 	text.setSize(320,32);
 	areaNombre = new JTextField();
 	areaNombre.setOpaque(true);
 	areaNombre.setLocation(310,318);
 	areaNombre.setSize(350,35);
 	areaNombre.setBackground(null);
 	areaNombre.setFont(new Font("Arial", Font.ITALIC, 28));
 	
 	
 	JTextField password = new JTextField();
 	password.setLocation(310, 380);
 	password.setSize(350,35);
 	password.setFont(new Font("Arial", Font.ITALIC, 28));
 	password.setOpaque(true);
 	password.setBackground(null);
 	panel.add(password);
 	
 	
 	JButton botonSend = new JButton("Entrar");
 	botonSend.setBackground(Color.green);
 	botonSend.setFont(new Font("Bauhaus 93", Font.ITALIC, 28));
 	botonSend.setBounds(340, 460, 225, 40);
 	botonSend.addActionListener(new ActionListener() {
		
		@Override
		public void actionPerformed(ActionEvent e) {
			if (areaNombre.getText().isEmpty())
				JOptionPane.showMessageDialog(null, "Ingrese nombre");
			else {
				
				response = areaNombre.getText();
				setVisible(false);
			}
			
		}
	});
 	setBackground(Color.BLACK);
 	panel.add(botonSend);
 	panel.add(areaNombre);
 	panel.add(text);
 	panel.repaint();
 	
 	setVisible(true);
	}
	

	
	private class Panel extends JPanel{

		/**
		 * 
		 */
		public Panel() {
			
		}
		private static final long serialVersionUID = 1L;

		
		@Override
		public void paintComponent(Graphics g) {
			// TODO Auto-generated method stub
			super.paintComponent(g);
			
			Graphics2D g2 = (Graphics2D) g;
			g2.drawImage(background, 0, 0, UserProfileModal.WIDTH, UserProfileModal.HEIGHT +1, null);
			g2.setColor(Color.WHITE);
			g2.setFont(new Font("Bauhaus 93", Font.ITALIC, 32));
			
			g2.setColor(Color.BLACK);

		}
		
		@Override
		public Dimension getPreferredSize() {
			// TODO Auto-generated method stub
			return new Dimension(WIDTH , HEIGHT);
		}
	}



	public String obtenerNombre() {
		// TODO Auto-generated method stub
		return null;
	}
	
}
