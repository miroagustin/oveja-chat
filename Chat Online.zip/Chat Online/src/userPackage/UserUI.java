package userPackage;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.time.LocalDateTime;

import javax.swing.DefaultListModel;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JList;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.text.DefaultCaret;

import resource.FontPersonalizado;
import server.Action;

public class UserUI extends JPanel {

	private static final long serialVersionUID = 1L;
	private final int WIDTH = 1080;
	private final int HEIGHT = 720;
	private AppChat window;
	private JTextArea areaChat;
	private JTextArea areaRespuesta;
	private JList<String> usuariosConectados;
	public int segundos = 0;
	public int hora = 0;
	public int minutos = 0;
	
	public UserUI(AppChat window) {
		
		this.window = window;
		setLayout(null);
		areaChat = new JTextArea();
		areaChat.setBounds(50, 400, 320, 320);
		
		areaChat.setBackground(Color.BLACK);
		areaChat.setForeground(Color.WHITE);
		areaChat.setFont(new Font("OCR A", Font.BOLD, 16));
		areaChat.setEditable(false);
		setBackground(Color.BLACK);
		JScrollPane paneScroll = new JScrollPane(areaChat);
		paneScroll.setBounds(80, 120, 600, 400);
		
		DefaultCaret caret = (DefaultCaret)areaChat.getCaret();
		caret.setUpdatePolicy(DefaultCaret.ALWAYS_UPDATE);
		add(paneScroll);
		
		
		areaRespuesta = new JTextArea();
		areaRespuesta.setBackground(Color.BLACK);
		areaRespuesta.setBounds(50, 400, 320, 320);
		areaRespuesta.setFont( new Font("OCR A", Font.BOLD, 16) );
		areaRespuesta.setForeground(Color.WHITE);
		areaRespuesta.setAutoscrolls(true);
		areaRespuesta.setRows(1);
		JScrollPane paneScrollRespuesta = new JScrollPane(areaRespuesta);
		paneScrollRespuesta.setBounds(80, 560, 600,40);
		add(paneScrollRespuesta);
		areaRespuesta.setColumns(1);


	    areaRespuesta.addKeyListener(new KeyListener() {
			
			@Override
			public void keyTyped(KeyEvent e) {
				// TODO Auto-generated method stub
				
			}
			
			@Override
			public void keyReleased(KeyEvent e) {
				// TODO Auto-generated method stub
				 if(e.getKeyCode() == KeyEvent.VK_ENTER){
					 
					 areaRespuesta.setText("");
				 }
			}
			
			@Override
			public void keyPressed(KeyEvent e) {
				 if(e.getKeyCode() == KeyEvent.VK_ENTER){

		            	window.enviarMensaje( window.getUserName() + " "+  window.obtenerFecha() + "  :  " + areaRespuesta.getText() + "\n", Action.ENVIARTEXTO);
						areaRespuesta.setText("");
				 }
				
			}
		});
	    JButton botonEnviarPrivado = new  JButton("Enviar Privado");
	    botonEnviarPrivado.setBounds(820,560,120,40);
	    botonEnviarPrivado.setBackground(Color.green);
	    botonEnviarPrivado.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				
			String names = "";
				 for(int i = 0; i< usuariosConectados.getModel().getSize();i++){
			           names+=(usuariosConectados.getModel().getElementAt(i)) + ":";
			        }
				
				PrivadoModal modalSalas	 = new PrivadoModal(window, true, names);
				
				String usuarioPrivate = modalSalas.nombreElejido;
				window.enviarMensaje( usuarioPrivate, Action.ENVIARPRIVADO);
				
				
			}
		});
	    add(botonEnviarPrivado);
	 	
	 	
	 	JButton botonEnviar = new  JButton("Enviar");
	 	botonEnviar.setBounds(700,560,80,40);
	 	botonEnviar.setBackground(Color.green);
	 	botonEnviar.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				window.enviarMensaje( window.getUserName() + " " +  window.obtenerFecha() +"  :  " + areaRespuesta.getText() + "\n", Action.ENVIARTEXTO);
				areaRespuesta.setText("");
			}
		});
	 	setSize(WIDTH, HEIGHT);
		add(botonEnviar);
		repaint();
		
	}
	

	

    

	@Override
	public void paintComponent(Graphics g) {
		// TODO Auto-generated method stub
		super.paintComponent(g);
		Graphics2D g2d = (Graphics2D)g;
		
		g2d.drawImage(window.backgroundChat, 0, 0, WIDTH, HEIGHT, null);
	
		g2d.setColor(Color.WHITE);
		g2d.setFont(new Font("Arial", Font.BOLD, 24));
		if (window.getUserName() != null)
			FontPersonalizado.dibujarTexto(g2d,  window.getUserName(), 35 , 58, 32,32, 25);

		
		if (window.getSalaActual() != null)
			FontPersonalizado.dibujarTexto(g2d,"Sala : " + window.getSalaActual(), 359 , 58, 20,20, 16);

		g2d.drawString("--Tiempo conectado :  " + this.hora  + " : " + this.minutos + " : " + this.segundos, 650, 58);
		FontPersonalizado.dibujarTexto(g2d,"Conectados", 690 , 145, 32,32, 25);
		
		g2d.setColor(Color.BLACK);
		//Dimension currentDimension = window.getContentPane().getSize();
		//g2d.scale(currentDimension.getWidth() / WIDTH, currentDimension.getHeight() / HEIGHT);
		
		
		
	}
	public void recibirChat(String mensaje) {
		this.areaChat.append(mensaje);
	}
	
	@Override
	public Dimension getPreferredSize() {
		// TODO Auto-generated method stub
		return new Dimension(WIDTH , HEIGHT);
	}
	public void agregarListaConectados() {
		String usuariosList[] = new String[4];
		usuariosList[0] = window.getUserName();
		usuariosConectados = new JList( usuariosList );
		usuariosConectados.setBounds(20, 260, 180, 150);
		usuariosConectados.setBackground(Color.BLACK);
		usuariosConectados.setFont( new Font("OCR A", Font.BOLD, 16) );
		usuariosConectados.setForeground(Color.WHITE);
	 	JScrollPane paneScroll2 = new JScrollPane(usuariosConectados);
	 	paneScroll2.setBounds(700, 180, 180 , 240);
		add(paneScroll2);
	}
	
	public void actualizarUsuarios(String usuarios) {
		
		String[] user = usuarios.split(":");
		DefaultListModel modelo = new DefaultListModel();
				
		for (String string : user) {
			modelo.addElement(string);
		}
		usuariosConectados.setModel(modelo);
		usuariosConectados.repaint();
		repaint();
	}

}
