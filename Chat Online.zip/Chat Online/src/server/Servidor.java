package server;

import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.ServerSocket;
import java.net.Socket;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map.Entry;

public class Servidor implements Runnable {
	private ObjectInputStream entrada;
	private ObjectOutputStream salida;
	private Socket socket;
	static HashMap<String , ArrayList<ClientService>> salas;
	static HashMap<String , ArrayList<ClientService>> historialChat;
	
	
	public Servidor(Socket socket2) throws IOException {
		entrada = new ObjectInputStream(socket2.getInputStream());
		salida = new ObjectOutputStream(socket2.getOutputStream());
	}


	public static void main(String[] args) {
		ServerSocket servidor;
		Servidor.salas = new HashMap<String , ArrayList<ClientService>>();
		Servidor.historialChat = new HashMap<String, ArrayList<ClientService>>();
		System.out.println("Iniciando Servidor....");

		salas.put("Sala Basica", new ArrayList<ClientService>());
		salas.put("Sala Deportes", new ArrayList<ClientService>());
		salas.put("Sala Economia", new ArrayList<ClientService>());
		salas.put("Sala UNLAM", new ArrayList<ClientService>());
		
		
		try {
			servidor = new ServerSocket(10578);
			
			while (true) {
				Socket socket ;
				socket = servidor.accept();
				System.out.print("conectaste");
				Servidor server = new Servidor(socket);
				new Thread(server).start();
			}
		} catch (Exception e) {
			// TODO: handle exception
		}
	}


	@Override
	public void run() {
		boolean canSend = true;
		PaqueteMensaje paqueteRespuesta;
		String salaActual = "";
		ClientService cliente = null;
		
		try {
			paqueteRespuesta = (PaqueteMensaje) entrada.readObject();
			cliente = new ClientService(paqueteRespuesta.text, salida, LocalDateTime.now());
			
			
			// Muestro salas
			cliente.getSalida().writeObject(new PaqueteMensaje(obtenerSalas(salas), Action.MOSTRARSALAS));
			
			
			paqueteRespuesta = (PaqueteMensaje) entrada.readObject();
			
			
			salaActual = paqueteRespuesta.text;
			
			
			if (!salas.containsKey(paqueteRespuesta.text)) {
				//ArrayList<ClientService> clientes = new ArrayList<ClientService>();
				ArrayList<ClientService> clientes = new ArrayList<ClientService>();
				clientes.add(cliente);
				salas.put(salaActual, clientes);				
				System.out.println("La sala no existia");
				System.out.println("Se creo el grupo : " + paqueteRespuesta.text);
			} else {
				System.out.println("La sala  existia");
				salas.get(salaActual).add(cliente);
			}
			


			
			enviarMensajeExcluyendome(cliente.getNombre() + " se unio al chat.\n", cliente.getSalida(), salas, salaActual);
			
			salida.writeObject(new PaqueteMensaje("Bienvenido al chat de ovejas\n", Action.MENSAJECHAT));
			salida.writeObject(new PaqueteMensaje(salas.toString(), Action.ELEJIRSALA));
			
			

		while (canSend) {
			
			paqueteRespuesta = (PaqueteMensaje) entrada.readObject();
			
			switch (paqueteRespuesta.accion) {
			case ENVIARPRIVADO:
				enviarPrivado(paqueteRespuesta.text , salas,salaActual);
				break;
			case MENSAJECHAT:
				
				break;
			case ENVIARTEXTO:
				enviarMensajeAGrupo(paqueteRespuesta.text, salas, salaActual);
				actualizarUsuarios(salas, salaActual);
			default:
				break;
			}
			
		}
			
		} catch (IOException | ClassNotFoundException e) {
			System.out.println("Se perdio la conexion de " + cliente.getNombre());
			salas.get(salaActual).remove(cliente);
			enviarMensajeAGrupo(cliente.getNombre() + "ha abandonado la sala , F por el o ella. \n", salas, salaActual);
			actualizarUsuarios(salas, salaActual);
			canSend = false;
		}
		
		
		
	}
	private void enviarPrivado(String text, HashMap<String, ArrayList<ClientService>> salas2, String salaActual) {
		// TODO Auto-generated method stub
		
		String[] mensaje = text.split("@");
		
		System.out.println(mensaje[1]);
				
		for (ClientService clienteActual : salas.get(salaActual)) {
			try {
				if (clienteActual.getNombre().equals(mensaje[0]) || clienteActual.getNombre().equals(mensaje[1]))
					clienteActual.getSalida().writeObject(new PaqueteMensaje(mensaje[2] , Action.ENVIARTEXTO));
				
				System.out.println(mensaje[1]);
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
	}


	private void actualizarUsuarios(HashMap<String, ArrayList<ClientService>> salas2, String salaActual) {

		for (ClientService clienteActual : salas.get(salaActual)) {
			try {
				clienteActual.getSalida().writeObject(new PaqueteMensaje(mostrarUsuarios(salas2, salaActual), Action.OBTENERUSUARIOS));
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		
	}


	private  void enviarMensajeAGrupo(String mensaje , HashMap<String, ArrayList<ClientService>> salas, String salaActual) {
		for (ClientService clienteActual : salas.get(salaActual)) {
			try {
				clienteActual.getSalida().writeObject(new PaqueteMensaje(mensaje, Action.ENVIARTEXTO));
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		
	}
	private void enviarMensajeExcluyendome(String mensaje,ObjectOutputStream salidaActual,HashMap<String, ArrayList<ClientService>> salas, String salaActual) {
		for (ClientService clienteActual : salas.get(salaActual)) {
			try {
				if (salidaActual != clienteActual.getSalida())
				clienteActual.getSalida().writeObject(new PaqueteMensaje(mensaje, Action.ENVIARTEXTO));
				clienteActual.getSalida().writeObject(new PaqueteMensaje(mostrarUsuarios(salas, salaActual), Action.OBTENERUSUARIOS));
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
	}
	private String obtenerSalas(HashMap<String, ArrayList<ClientService>> salas) {
		
		String salasTotal = "";
		
		 for (Entry<String, ArrayList<ClientService>> entry : salas.entrySet())
	            salasTotal += entry.getKey() + ", conectados  " + salas.get(entry.getKey()).size() + "/20 " + " :";
	    
		return salasTotal;
	}
	
	private String mostrarUsuarios(HashMap<String, ArrayList<ClientService>> salas, String salaActual) {
		String userTotals = "";
		for (ClientService clienteActual : salas.get(salaActual)) {
			userTotals += clienteActual.getNombre() + ":";
			
		}
		
		return userTotals;
	}
}
