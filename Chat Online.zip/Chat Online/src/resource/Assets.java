package resource;

import java.awt.image.BufferedImage;

public class Assets {
	static public BufferedImage backgroundChat;
	
	
}
